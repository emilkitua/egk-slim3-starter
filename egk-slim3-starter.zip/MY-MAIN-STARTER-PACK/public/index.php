<?php
require_once __DIR__ . '/../bootstrap/app.php';

// Run app
$app->run();
